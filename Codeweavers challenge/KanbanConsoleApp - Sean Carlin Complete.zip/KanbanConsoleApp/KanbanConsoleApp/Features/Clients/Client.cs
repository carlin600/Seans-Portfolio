﻿namespace KanbanConsoleApp.Features.Clients
{
    public class Client
    {
        public string Name { get; set; }
    }
}