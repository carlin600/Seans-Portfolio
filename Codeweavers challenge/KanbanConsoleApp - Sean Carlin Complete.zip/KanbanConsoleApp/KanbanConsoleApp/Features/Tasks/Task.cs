﻿namespace KanbanConsoleApp.Features.Tasks
{
    public class Task
    {
        public string Id { get; set; }
        public string Description { get; set; }
        public string ClientName { get; set; }
    }
}
